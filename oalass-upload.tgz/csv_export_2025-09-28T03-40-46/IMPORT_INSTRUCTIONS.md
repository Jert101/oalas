# TiDB Import Instructions

## Export Summary
- **Export Date:** 9/28/2025, 11:40:46 AM
- **Total Tables:** 9
- **Successful Exports:** 9

## CSV Files Generated
- `users.csv` - 10 rows
- `roles.csv` - 13 rows
- `statuses.csv` - 5 rows
- `departments.csv` - 6 rows
- `leave_types.csv` - 6 rows
- `term_types.csv` - 2 rows
- `calendar_periods.csv` - 1 rows
- `leave_limits.csv` - 20 rows
- `leave_balances.csv` - 30 rows

## Import Steps for TiDB

1. **Create Database in TiDB:**
   ```sql
   CREATE DATABASE your_database_name;
   USE your_database_name;
   ```

2. **Import Tables in Order:**
   Import tables in dependency order (tables without foreign keys first):
   
   ```bash
   # Example import command for each table
   mysql -h tidb-host -u username -p database_name -e "
   LOAD DATA LOCAL INFILE 'table_name.csv' 
   INTO TABLE table_name 
   FIELDS TERMINATED BY ',' 
   ENCLOSED BY '"' 
   LINES TERMINATED BY '\n' 
   IGNORE 1 ROWS;"
   ```

3. **Recommended Import Order:**
   - roles.csv
   - status.csv  
   - departments.csv
   - leave_types.csv
   - term_types.csv
   - users.csv
   - calendar_periods.csv
   - leave_limits.csv
   - leave_balances.csv
   - leave_applications.csv
   - travel_orders.csv
   - notifications.csv

## Important Notes
- ⚠️ **Test on development environment first**
- 🔒 **Original database remains unchanged**
- 📊 **Verify row counts after import**
- 🔗 **Check foreign key constraints**

## Verification Queries
```sql
SELECT COUNT(*) FROM users; -- Expected: 10 rows
SELECT COUNT(*) FROM roles; -- Expected: 13 rows
SELECT COUNT(*) FROM statuses; -- Expected: 5 rows
SELECT COUNT(*) FROM departments; -- Expected: 6 rows
SELECT COUNT(*) FROM leave_types; -- Expected: 6 rows
SELECT COUNT(*) FROM term_types; -- Expected: 2 rows
SELECT COUNT(*) FROM calendar_periods; -- Expected: 1 rows
SELECT COUNT(*) FROM leave_limits; -- Expected: 20 rows
SELECT COUNT(*) FROM leave_balances; -- Expected: 30 rows
```
