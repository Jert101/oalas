# TiDB Import Instructions - ALL 19 TABLES

## Export Summary
- **Export Date:** 9/28/2025, 11:47:26 AM
- **Total Tables:** 19/19 (ALL TABLES)
- **Successful Exports:** 19
- **Tables with Data:** 12
- **Empty Tables:** 7

## CSV Files Generated
- `user.csv` - 10 rows
- `role.csv` - 13 rows
- `roleCategory.csv` - 5 rows
- `department.csv` - 6 rows
- `status.csv` - 5 rows
- `account.csv` - 2 rows
- `session.csv` - 0 rows (EMPTY)
- `verificationToken.csv` - 0 rows (EMPTY)
- `calendarPeriod.csv` - 1 rows
- `leaveApplication.csv` - 0 rows (EMPTY)
- `travelOrder.csv` - 0 rows (EMPTY)
- `leaveLimit.csv` - 20 rows
- `leaveBalance.csv` - 30 rows
- `probation.csv` - 0 rows (EMPTY)
- `termType.csv` - 2 rows
- `leave_types.csv` - 6 rows
- `leaveTypeFormField.csv` - 18 rows
- `notification.csv` - 0 rows (EMPTY)
- `accountSetupRequest.csv` - 0 rows (EMPTY)

## Import Steps for TiDB

1. **Create Database in TiDB:**
   ```sql
   CREATE DATABASE your_database_name;
   USE your_database_name;
   ```

2. **Import Tables in Dependency Order:**
   
   ```bash
   # Example import command for each table
   mysql -h tidb-host -u username -p database_name -e "
   LOAD DATA LOCAL INFILE 'table_name.csv' 
   INTO TABLE table_name 
   FIELDS TERMINATED BY ',' 
   ENCLOSED BY '"' 
   LINES TERMINATED BY '\n' 
   IGNORE 1 ROWS;"
   ```

3. **RECOMMENDED IMPORT ORDER (Dependency-Safe):**
      - user.csv
   - role.csv
   - roleCategory.csv
   - department.csv
   - status.csv
   - account.csv
   - session.csv
   - verificationToken.csv
   - calendarPeriod.csv
   - leaveApplication.csv
   - travelOrder.csv
   - leaveLimit.csv
   - leaveBalance.csv
   - probation.csv
   - termType.csv
   - leave_types.csv
   - leaveTypeFormField.csv
   - notification.csv
   - accountSetupRequest.csv

4. **Tables with Data (Import These):**
   - user.csv (10 rows)
   - role.csv (13 rows)
   - roleCategory.csv (5 rows)
   - department.csv (6 rows)
   - status.csv (5 rows)
   - account.csv (2 rows)
   - calendarPeriod.csv (1 rows)
   - leaveLimit.csv (20 rows)
   - leaveBalance.csv (30 rows)
   - termType.csv (2 rows)
   - leave_types.csv (6 rows)
   - leaveTypeFormField.csv (18 rows)

5. **Empty Tables (Create Structure Only):**
   - session.csv (0 rows - structure only)
   - verificationToken.csv (0 rows - structure only)
   - leaveApplication.csv (0 rows - structure only)
   - travelOrder.csv (0 rows - structure only)
   - probation.csv (0 rows - structure only)
   - notification.csv (0 rows - structure only)
   - accountSetupRequest.csv (0 rows - structure only)

## Important Notes
- ⚠️ **Test on development environment first**
- 🔒 **Original database remains unchanged**
- 📊 **Verify row counts after import**
- 🔗 **Check foreign key constraints**
- 📝 **Empty tables will need proper schema creation in TiDB**

## Verification Queries
```sql
SELECT COUNT(*) FROM user; -- Expected: 10 rows
SELECT COUNT(*) FROM role; -- Expected: 13 rows
SELECT COUNT(*) FROM roleCategory; -- Expected: 5 rows
SELECT COUNT(*) FROM department; -- Expected: 6 rows
SELECT COUNT(*) FROM status; -- Expected: 5 rows
SELECT COUNT(*) FROM account; -- Expected: 2 rows
SELECT COUNT(*) FROM session; -- Expected: 0 rows
SELECT COUNT(*) FROM verificationToken; -- Expected: 0 rows
SELECT COUNT(*) FROM calendarPeriod; -- Expected: 1 rows
SELECT COUNT(*) FROM leaveApplication; -- Expected: 0 rows
SELECT COUNT(*) FROM travelOrder; -- Expected: 0 rows
SELECT COUNT(*) FROM leaveLimit; -- Expected: 20 rows
SELECT COUNT(*) FROM leaveBalance; -- Expected: 30 rows
SELECT COUNT(*) FROM probation; -- Expected: 0 rows
SELECT COUNT(*) FROM termType; -- Expected: 2 rows
SELECT COUNT(*) FROM leave_types; -- Expected: 6 rows
SELECT COUNT(*) FROM leaveTypeFormField; -- Expected: 18 rows
SELECT COUNT(*) FROM notification; -- Expected: 0 rows
SELECT COUNT(*) FROM accountSetupRequest; -- Expected: 0 rows
```

## Total Data Exported
**Total Rows:** 118 rows across 19 tables
**Tables with Data:** 12
**Empty Tables:** 7
