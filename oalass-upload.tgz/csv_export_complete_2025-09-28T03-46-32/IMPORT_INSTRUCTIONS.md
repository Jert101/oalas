# TiDB Import Instructions - COMPLETE DATABASE

## Export Summary
- **Export Date:** 9/28/2025, 11:46:33 AM
- **Total Tables:** 12 (ALL 19 TABLES)
- **Successful Exports:** 12

## CSV Files Generated
- `user.csv` - 10 rows
- `role.csv` - 13 rows
- `roleCategory.csv` - 5 rows
- `department.csv` - 6 rows
- `status.csv` - 5 rows
- `account.csv` - 2 rows
- `calendarPeriod.csv` - 1 rows
- `leaveLimit.csv` - 20 rows
- `leaveBalance.csv` - 30 rows
- `termType.csv` - 2 rows
- `leave_types.csv` - 6 rows
- `leaveTypeFormField.csv` - 18 rows

## Import Steps for TiDB

1. **Create Database in TiDB:**
   ```sql
   CREATE DATABASE your_database_name;
   USE your_database_name;
   ```

2. **Import Tables in Dependency Order:**
   Import tables in this order to respect foreign key constraints:
   
   ```bash
   # Example import command for each table
   mysql -h tidb-host -u username -p database_name -e "
   LOAD DATA LOCAL INFILE 'table_name.csv' 
   INTO TABLE table_name 
   FIELDS TERMINATED BY ',' 
   ENCLOSED BY '"' 
   LINES TERMINATED BY '\n' 
   IGNORE 1 ROWS;"
   ```

3. **RECOMMENDED IMPORT ORDER (Dependency-Safe):**
   - roleCategory.csv (no dependencies)
   - role.csv (depends on roleCategory)
   - status.csv (no dependencies)
   - department.csv (no dependencies)
   - termType.csv (no dependencies)
   - leave_types.csv (no dependencies)
   - user.csv (depends on role, department, status)
   - account.csv (depends on user)
   - session.csv (depends on user)
   - verificationToken.csv (depends on user)
   - calendarPeriod.csv (depends on termType)
   - leaveTypeFormField.csv (depends on leave_types)
   - leaveLimit.csv (depends on status, termType, leave_types)
   - leaveBalance.csv (depends on user, calendarPeriod, termType, leave_types, status)
   - leaveApplication.csv (depends on user, leave_types, calendarPeriod)
   - travelOrder.csv (depends on user, calendarPeriod)
   - probation.csv (depends on user)
   - notification.csv (depends on user)
   - accountSetupRequest.csv (depends on user)

## Important Notes
- ⚠️ **Test on development environment first**
- 🔒 **Original database remains unchanged**
- 📊 **Verify row counts after import**
- 🔗 **Check foreign key constraints**
- 📝 **Import in the exact order listed above**

## Verification Queries
```sql
SELECT COUNT(*) FROM user; -- Expected: 10 rows
SELECT COUNT(*) FROM role; -- Expected: 13 rows
SELECT COUNT(*) FROM roleCategory; -- Expected: 5 rows
SELECT COUNT(*) FROM department; -- Expected: 6 rows
SELECT COUNT(*) FROM status; -- Expected: 5 rows
SELECT COUNT(*) FROM account; -- Expected: 2 rows
SELECT COUNT(*) FROM calendarPeriod; -- Expected: 1 rows
SELECT COUNT(*) FROM leaveLimit; -- Expected: 20 rows
SELECT COUNT(*) FROM leaveBalance; -- Expected: 30 rows
SELECT COUNT(*) FROM termType; -- Expected: 2 rows
SELECT COUNT(*) FROM leave_types; -- Expected: 6 rows
SELECT COUNT(*) FROM leaveTypeFormField; -- Expected: 18 rows
```

## Total Data Exported
**Total Rows:** 118 rows across 12 tables
